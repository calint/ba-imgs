#!/bin/sh

cd /baba-chess-trainer &&
java -cp bin b.b server_port 80
