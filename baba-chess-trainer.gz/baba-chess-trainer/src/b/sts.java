package b;
public interface sts{
	void setsts(String s)throws Throwable;
	void flush()throws Throwable;
}
