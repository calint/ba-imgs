package b;public interface threadedsock{}
