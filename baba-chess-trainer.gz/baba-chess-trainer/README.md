# baba-chess-trainer
web based app that extracts chess problems from pgn files by finding the first move that changes position evaluation above a configurable value

